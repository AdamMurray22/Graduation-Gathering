import validateCode.package.jwt as jwt
import time
import boto3
import json
import logging
from botocore.exceptions import ClientError
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

key = os.environ['key']

def generateToken(email, userID):
    
    header = {
    'alg': 'HS256',
    'typ': 'JWT'
    }
    payload = {
        'id': userID,
        'email': email,
        'created': time.time(),
        'expires': time.time() + (60*60*24)
    }

    message = (json.dumps(header) + '.' + json.dumps(payload)).encode('utf-8')

    secret = get_secret()

    encoded_jwt = jwt.encode(message, secret, algorithm="HS256")

    token = encoded_jwt
    return token

def get_secret():
    return key