import validateCode.package.jwt as jwt
import time
import boto3
import json

client = boto3.client('kms')

def generateToken(email):
    header = {
    "alg": "RS256",
    "typ": "JWT"
    }
    payload = {
        "email": email,
        "created": time.time(),
        "expires": time.time() + (60*60*24)
    }

    message = json.dumps({"header": header, "payload": payload})
    message = message.encode("utf-8")

    return client.sign(
        KeyId='e452d056-1194-44fd-9b9c-4cb775c10abb',
        Message=message,
        MessageType='RAW',
        SigningAlgorithm='RSASSA_PSS_SHA_256',
    )